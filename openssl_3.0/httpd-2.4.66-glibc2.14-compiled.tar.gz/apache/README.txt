Apache HTTP Server 2.4.66 - Portable Build
=====================================================
빌드일시  : 2026-04-07 22:18:29
컴파일경로: /Product/httpd-2.4.66-build/package/apache

[포함 구성요소]
  httpd    2.4.66      APR      1.7.6
  APR-util 1.6.3   OpenSSL  3.0.17
  PCRE2    10.45       zlib     1.3.1
  expat    2.7.1    nghttp2  1.65.0

[사용법]
  bin/start.sh       Apache 시작 (첫 실행 시 경로 자동 재설정)
  bin/stop.sh        Apache 중지
  bin/restart.sh     Apache 재시작 (graceful)
  bin/status.sh      실행 상태 확인

[경로 재배치]
  다른 경로 설치 시 start.sh 가 자동으로 경로를 재설정합니다.
  수동 강제 재설정: FORCE_RELOCATE=1 bin/start.sh

[의존 라이브러리]
  bins/ 하위에 모두 포함되어 있습니다. 시스템에 별도 설치 불필요.
