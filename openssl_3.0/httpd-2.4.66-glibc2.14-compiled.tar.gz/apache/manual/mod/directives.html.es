<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es"><head>
<meta content="text/html; charset=ISO-8859-1" http-equiv="Content-Type" />
<!--
        XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
              This file is generated from xml source: DO NOT EDIT
        XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
      -->
<title>&#205;ndice de Directivas - Servidor HTTP Apache Versi&#243;n 2.4</title>
<link href="../style/css/manual.css" rel="stylesheet" media="all" type="text/css" title="Main stylesheet" />
<link href="../style/css/manual-loose-100pc.css" rel="alternate stylesheet" media="all" type="text/css" title="No Sidebar - Default font size" />
<link href="../style/css/manual-print.css" rel="stylesheet" media="print" type="text/css" /><link rel="stylesheet" type="text/css" href="../style/css/prettify.css" />
<script src="../style/scripts/prettify.min.js" type="text/javascript">
</script>

<link href="../images/favicon.png" rel="shortcut icon" /></head>
<body id="directive-index"><div id="page-header">
<p class="menu"><a href="../mod/">M&#243;dulos</a> | <a href="../mod/directives.html">Directivas</a> | <a href="http://wiki.apache.org/httpd/FAQ">Preguntas Frecuentes</a> | <a href="../glossary.html">Glosario</a> | <a href="../sitemap.html">Mapa del sitio web</a></p>
<p class="apache">Versi&#243;n 2.4 del Servidor HTTP Apache</p>
<img alt="" src="../images/feather.png" /></div>
<div class="up"><a href="./"><img title="&lt;-" alt="&lt;-" src="../images/left.gif" /></a></div>
<div id="path">
<a href="http://www.apache.org/">Apache</a> &gt; <a href="http://httpd.apache.org/">Servidor HTTP</a> &gt; <a href="http://httpd.apache.org/docs/">Documentaci&#243;n</a> &gt; <a href="../">Versi&#243;n 2.4</a> &gt; <a href="./">M&#243;dulos</a></div><div id="preamble"><h1>&#205;ndice de Directivas</h1>
<div class="toplang">
<p><span>Idiomas disponibles: </span><a href="../de/mod/directives.html" hreflang="de" rel="alternate" title="Deutsch">&nbsp;de&nbsp;</a> |
<a href="../en/mod/directives.html" hreflang="en" rel="alternate" title="English">&nbsp;en&nbsp;</a> |
<a href="../es/mod/directives.html" title="Espa&#241;ol">&nbsp;es&nbsp;</a> |
<a href="../fr/mod/directives.html" hreflang="fr" rel="alternate" title="Fran&#231;ais">&nbsp;fr&nbsp;</a> |
<a href="../ja/mod/directives.html" hreflang="ja" rel="alternate" title="Japanese">&nbsp;ja&nbsp;</a> |
<a href="../ko/mod/directives.html" hreflang="ko" rel="alternate" title="Korean">&nbsp;ko&nbsp;</a> |
<a href="../tr/mod/directives.html" hreflang="tr" rel="alternate" title="T&#252;rk&#231;e">&nbsp;tr&nbsp;</a> |
<a href="../zh-cn/mod/directives.html" hreflang="zh-cn" rel="alternate" title="Simplified Chinese">&nbsp;zh-cn&nbsp;</a></p>
</div>

    <p>
      Todas las directivas disponibles en la distribuci&#243;n
      est&#225;ndar de Apache est&#225;n en la lista que se muestra m&#225;s
      abajo. Cada una se describe usando un formato uniforme, y existe
      un <a href="directive-dict.html" rel="Glossary">glosario</a>
      de los t&#233;rminos usados en las descripciones que puede 
      consultar.
    </p>

    <p>
      Tambi&#233;n existe una <a href="quickreference.html">Gu&#237;a R&#225;pida de
      Referencia de Directivas</a> con informaci&#243;n de cada
      directiva de forma resumida.
    </p>
  
<p class="letters"><a href="#A">&nbsp;A&nbsp;</a> | <a href="#B">&nbsp;B&nbsp;</a> | <a href="#C">&nbsp;C&nbsp;</a> | <a href="#D">&nbsp;D&nbsp;</a> | <a href="#E">&nbsp;E&nbsp;</a> | <a href="#F">&nbsp;F&nbsp;</a> | <a href="#G">&nbsp;G&nbsp;</a> | <a href="#H">&nbsp;H&nbsp;</a> | <a href="#I">&nbsp;I&nbsp;</a> | <a href="#K">&nbsp;K&nbsp;</a> | <a href="#L">&nbsp;L&nbsp;</a> | <a href="#M">&nbsp;M&nbsp;</a> | <a href="#N">&nbsp;N&nbsp;</a> | <a href="#O">&nbsp;O&nbsp;</a> | <a href="#P">&nbsp;P&nbsp;</a> | <a href="#Q">&nbsp;Q&nbsp;</a> | <a href="#R">&nbsp;R&nbsp;</a> | <a href="#S">&nbsp;S&nbsp;</a> | <a href="#T">&nbsp;T&nbsp;</a> | <a href="#U">&nbsp;U&nbsp;</a> | <a href="#V">&nbsp;V&nbsp;</a> | <a href="#W">&nbsp;W&nbsp;</a> | <a href="#X">&nbsp;X&nbsp;</a></p>
</div>
<div id="directive-list"><ul>
<li><a href="core.html#acceptfilter" id="A" name="A">AcceptFilter</a></li>
<li><a href="core.html#acceptpathinfo">AcceptPathInfo</a></li>
<li><a href="core.html#accessfilename">AccessFileName</a></li>
<li><a href="mod_actions.html#action">Action</a></li>
<li><a href="mod_autoindex.html#addalt">AddAlt</a></li>
<li><a href="mod_autoindex.html#addaltbyencoding">AddAltByEncoding</a></li>
<li><a href="mod_autoindex.html#addaltbytype">AddAltByType</a></li>
<li><a href="mod_mime.html#addcharset">AddCharset</a></li>
<li><a href="core.html#adddefaultcharset">AddDefaultCharset</a></li>
<li><a href="mod_autoindex.html#adddescription">AddDescription</a></li>
<li><a href="mod_mime.html#addencoding">AddEncoding</a></li>
<li><a href="mod_mime.html#addhandler">AddHandler</a></li>
<li><a href="mod_autoindex.html#addicon">AddIcon</a></li>
<li><a href="mod_autoindex.html#addiconbyencoding">AddIconByEncoding</a></li>
<li><a href="mod_autoindex.html#addiconbytype">AddIconByType</a></li>
<li><a href="mod_mime.html#addinputfilter">AddInputFilter</a></li>
<li><a href="mod_mime.html#addlanguage">AddLanguage</a></li>
<li><a href="mod_info.html#addmoduleinfo">AddModuleInfo</a></li>
<li><a href="mod_mime.html#addoutputfilter">AddOutputFilter</a></li>
<li><a href="mod_filter.html#addoutputfilterbytype">AddOutputFilterByType</a></li>
<li><a href="mod_mime.html#addtype">AddType</a></li>
<li><a href="mod_alias.html#alias">Alias</a></li>
<li><a href="mod_alias.html#aliasmatch">AliasMatch</a></li>
<li><a href="mod_alias.html#aliaspreservepath">AliasPreservePath</a></li>
<li><a href="mod_access_compat.html#allow">Allow</a></li>
<li><a href="mod_proxy_connect.html#allowconnect">AllowCONNECT</a></li>
<li><a href="core.html#allowencodedslashes">AllowEncodedSlashes</a></li>
<li><a href="mod_allowmethods.html#allowmethods">AllowMethods</a></li>
<li><a href="core.html#allowoverride">AllowOverride</a></li>
<li><a href="core.html#allowoverridelist">AllowOverrideList</a></li>
<li><a href="mod_authn_anon.html#anonymous">Anonymous</a></li>
<li><a href="mod_authn_anon.html#anonymous_logemail">Anonymous_LogEmail</a></li>
<li><a href="mod_authn_anon.html#anonymous_mustgiveemail">Anonymous_MustGiveEmail</a></li>
<li><a href="mod_authn_anon.html#anonymous_nouserid">Anonymous_NoUserID</a></li>
<li><a href="mod_authn_anon.html#anonymous_verifyemail">Anonymous_VerifyEmail</a></li>
<li><a href="event.html#asyncrequestworkerfactor">AsyncRequestWorkerFactor</a></li>
<li><a href="mod_auth_basic.html#authbasicauthoritative">AuthBasicAuthoritative</a></li>
<li><a href="mod_auth_basic.html#authbasicfake">AuthBasicFake</a></li>
<li><a href="mod_auth_basic.html#authbasicprovider">AuthBasicProvider</a></li>
<li><a href="mod_auth_basic.html#authbasicusedigestalgorithm">AuthBasicUseDigestAlgorithm</a></li>
<li><a href="mod_authn_dbd.html#authdbduserpwquery">AuthDBDUserPWQuery</a></li>
<li><a href="mod_authn_dbd.html#authdbduserrealmquery">AuthDBDUserRealmQuery</a></li>
<li><a href="mod_authz_dbm.html#authdbmgroupfile">AuthDBMGroupFile</a></li>
<li><a href="mod_authn_dbm.html#authdbmtype">AuthDBMType</a></li>
<li><a href="mod_authn_dbm.html#authdbmuserfile">AuthDBMUserFile</a></li>
<li><a href="mod_auth_digest.html#authdigestalgorithm">AuthDigestAlgorithm</a></li>
<li><a href="mod_auth_digest.html#authdigestdomain">AuthDigestDomain</a></li>
<li><a href="mod_auth_digest.html#authdigestnoncelifetime">AuthDigestNonceLifetime</a></li>
<li><a href="mod_auth_digest.html#authdigestprovider">AuthDigestProvider</a></li>
<li><a href="mod_auth_digest.html#authdigestqop">AuthDigestQop</a></li>
<li><a href="mod_auth_digest.html#authdigestshmemsize">AuthDigestShmemSize</a></li>
<li><a href="mod_auth_form.html#authformauthoritative">AuthFormAuthoritative</a></li>
<li><a href="mod_auth_form.html#authformbody">AuthFormBody</a></li>
<li><a href="mod_auth_form.html#authformdisablenostore">AuthFormDisableNoStore</a></li>
<li><a href="mod_auth_form.html#authformfakebasicauth">AuthFormFakeBasicAuth</a></li>
<li><a href="mod_auth_form.html#authformlocation">AuthFormLocation</a></li>
<li><a href="mod_auth_form.html#authformloginrequiredlocation">AuthFormLoginRequiredLocation</a></li>
<li><a href="mod_auth_form.html#authformloginsuccesslocation">AuthFormLoginSuccessLocation</a></li>
<li><a href="mod_auth_form.html#authformlogoutlocation">AuthFormLogoutLocation</a></li>
<li><a href="mod_auth_form.html#authformmethod">AuthFormMethod</a></li>
<li><a href="mod_auth_form.html#authformmimetype">AuthFormMimetype</a></li>
<li><a href="mod_auth_form.html#authformpassword">AuthFormPassword</a></li>
<li><a href="mod_auth_form.html#authformprovider">AuthFormProvider</a></li>
<li><a href="mod_auth_form.html#authformsitepassphrase">AuthFormSitePassphrase</a></li>
<li><a href="mod_auth_form.html#authformsize">AuthFormSize</a></li>
<li><a href="mod_auth_form.html#authformusername">AuthFormUsername</a></li>
<li><a href="mod_authz_groupfile.html#authgroupfile">AuthGroupFile</a></li>
<li><a href="mod_authnz_ldap.html#authldapauthorizeprefix">AuthLDAPAuthorizePrefix</a></li>
<li><a href="mod_authnz_ldap.html#authldapbindauthoritative">AuthLDAPBindAuthoritative</a></li>
<li><a href="mod_authnz_ldap.html#authldapbinddn">AuthLDAPBindDN</a></li>
<li><a href="mod_authnz_ldap.html#authldapbindpassword">AuthLDAPBindPassword</a></li>
<li><a href="mod_authnz_ldap.html#authldapcharsetconfig">AuthLDAPCharsetConfig</a></li>
<li><a href="mod_authnz_ldap.html#authldapcompareasuser">AuthLDAPCompareAsUser</a></li>
<li><a href="mod_authnz_ldap.html#authldapcomparednonserver">AuthLDAPCompareDNOnServer</a></li>
<li><a href="mod_authnz_ldap.html#authldapdereferencealiases">AuthLDAPDereferenceAliases</a></li>
<li><a href="mod_authnz_ldap.html#authldapgroupattribute">AuthLDAPGroupAttribute</a></li>
<li><a href="mod_authnz_ldap.html#authldapgroupattributeisdn">AuthLDAPGroupAttributeIsDN</a></li>
<li><a href="mod_authnz_ldap.html#authldapinitialbindasuser">AuthLDAPInitialBindAsUser</a></li>
<li><a href="mod_authnz_ldap.html#authldapinitialbindpattern">AuthLDAPInitialBindPattern</a></li>
<li><a href="mod_authnz_ldap.html#authldapmaxsubgroupdepth">AuthLDAPMaxSubGroupDepth</a></li>
<li><a href="mod_authnz_ldap.html#authldapremoteuserattribute">AuthLDAPRemoteUserAttribute</a></li>
<li><a href="mod_authnz_ldap.html#authldapremoteuserisdn">AuthLDAPRemoteUserIsDN</a></li>
<li><a href="mod_authnz_ldap.html#authldapsearchasuser">AuthLDAPSearchAsUser</a></li>
<li><a href="mod_authnz_ldap.html#authldapsubgroupattribute">AuthLDAPSubGroupAttribute</a></li>
<li><a href="mod_authnz_ldap.html#authldapsubgroupclass">AuthLDAPSubGroupClass</a></li>
<li><a href="mod_authnz_ldap.html#authldapurl">AuthLDAPURL</a></li>
<li><a href="mod_authz_core.html#authmerging">AuthMerging</a></li>
<li><a href="mod_authn_core.html#authname">AuthName</a></li>
<li><a href="mod_authn_socache.html#authncachecontext">AuthnCacheContext</a></li>
<li><a href="mod_authn_socache.html#authncacheenable">AuthnCacheEnable</a></li>
<li><a href="mod_authn_socache.html#authncacheprovidefor">AuthnCacheProvideFor</a></li>
<li><a href="mod_authn_socache.html#authncachesocache">AuthnCacheSOCache</a></li>
<li><a href="mod_authn_socache.html#authncachetimeout">AuthnCacheTimeout</a></li>
<li><a href="mod_authn_core.html#authnprovideralias">&lt;AuthnProviderAlias&gt;</a></li>
<li><a href="mod_authnz_fcgi.html#authnzfcgicheckauthnprovider">AuthnzFcgiCheckAuthnProvider</a></li>
<li><a href="mod_authnz_fcgi.html#authnzfcgidefineprovider">AuthnzFcgiDefineProvider</a></li>
<li><a href="mod_authn_core.html#authtype">AuthType</a></li>
<li><a href="mod_authn_file.html#authuserfile">AuthUserFile</a></li>
<li><a href="mod_authz_dbd.html#authzdbdlogintoreferer">AuthzDBDLoginToReferer</a></li>
<li><a href="mod_authz_dbd.html#authzdbdquery">AuthzDBDQuery</a></li>
<li><a href="mod_authz_dbd.html#authzdbdredirectquery">AuthzDBDRedirectQuery</a></li>
<li><a href="mod_authz_dbm.html#authzdbmtype">AuthzDBMType</a></li>
<li><a href="mod_authz_core.html#authzprovideralias">&lt;AuthzProviderAlias&gt;</a></li>
<li><a href="mod_authz_core.html#authzsendforbiddenonfailure">AuthzSendForbiddenOnFailure</a></li>
<li><a href="mod_proxy.html#balancergrowth" id="B" name="B">BalancerGrowth</a></li>
<li><a href="mod_proxy.html#balancerinherit">BalancerInherit</a></li>
<li><a href="mod_proxy.html#balancermember">BalancerMember</a></li>
<li><a href="mod_proxy.html#balancerpersist">BalancerPersist</a></li>
<li><a href="mod_brotli.html#brotlialteretag">BrotliAlterETag</a></li>
<li><a href="mod_brotli.html#brotlicompressionmaxinputblock">BrotliCompressionMaxInputBlock</a></li>
<li><a href="mod_brotli.html#brotlicompressionquality">BrotliCompressionQuality</a></li>
<li><a href="mod_brotli.html#brotlicompressionwindow">BrotliCompressionWindow</a></li>
<li><a href="mod_brotli.html#brotlifilternote">BrotliFilterNote</a></li>
<li><a href="mod_setenvif.html#browsermatch">BrowserMatch</a></li>
<li><a href="mod_setenvif.html#browsermatchnocase">BrowserMatchNoCase</a></li>
<li><a href="mod_log_config.html#bufferedlogs">BufferedLogs</a></li>
<li><a href="mod_buffer.html#buffersize">BufferSize</a></li>
<li><a href="mod_cache.html#cachedefaultexpire" id="C" name="C">CacheDefaultExpire</a></li>
<li><a href="mod_cache.html#cachedetailheader">CacheDetailHeader</a></li>
<li><a href="mod_cache_disk.html#cachedirlength">CacheDirLength</a></li>
<li><a href="mod_cache_disk.html#cachedirlevels">CacheDirLevels</a></li>
<li><a href="mod_cache.html#cachedisable">CacheDisable</a></li>
<li><a href="mod_cache.html#cacheenable">CacheEnable</a></li>
<li><a href="mod_file_cache.html#cachefile">CacheFile</a></li>
<li><a href="mod_cache.html#cacheheader">CacheHeader</a></li>
<li><a href="mod_cache.html#cacheignorecachecontrol">CacheIgnoreCacheControl</a></li>
<li><a href="mod_cache.html#cacheignoreheaders">CacheIgnoreHeaders</a></li>
<li><a href="mod_cache.html#cacheignorenolastmod">CacheIgnoreNoLastMod</a></li>
<li><a href="mod_cache.html#cacheignorequerystring">CacheIgnoreQueryString</a></li>
<li><a href="mod_cache.html#cacheignoreurlsessionidentifiers">CacheIgnoreURLSessionIdentifiers</a></li>
<li><a href="mod_cache.html#cachekeybaseurl">CacheKeyBaseURL</a></li>
<li><a href="mod_cache.html#cachelastmodifiedfactor">CacheLastModifiedFactor</a></li>
<li><a href="mod_cache.html#cachelock">CacheLock</a></li>
<li><a href="mod_cache.html#cachelockmaxage">CacheLockMaxAge</a></li>
<li><a href="mod_cache.html#cachelockpath">CacheLockPath</a></li>
<li><a href="mod_cache.html#cachemaxexpire">CacheMaxExpire</a></li>
<li><a href="mod_cache_disk.html#cachemaxfilesize">CacheMaxFileSize</a></li>
<li><a href="mod_cache.html#cacheminexpire">CacheMinExpire</a></li>
<li><a href="mod_cache_disk.html#cacheminfilesize">CacheMinFileSize</a></li>
<li><a href="mod_negotiation.html#cachenegotiateddocs">CacheNegotiatedDocs</a></li>
<li><a href="mod_cache.html#cachequickhandler">CacheQuickHandler</a></li>
<li><a href="mod_cache_disk.html#cachereadsize">CacheReadSize</a></li>
<li><a href="mod_cache_disk.html#cachereadtime">CacheReadTime</a></li>
<li><a href="mod_cache_disk.html#cacheroot">CacheRoot</a></li>
<li><a href="mod_cache_socache.html#cachesocache">CacheSocache</a></li>
<li><a href="mod_cache_socache.html#cachesocachemaxsize">CacheSocacheMaxSize</a></li>
<li><a href="mod_cache_socache.html#cachesocachemaxtime">CacheSocacheMaxTime</a></li>
<li><a href="mod_cache_socache.html#cachesocachemintime">CacheSocacheMinTime</a></li>
<li><a href="mod_cache_socache.html#cachesocachereadsize">CacheSocacheReadSize</a></li>
<li><a href="mod_cache_socache.html#cachesocachereadtime">CacheSocacheReadTime</a></li>
<li><a href="mod_cache.html#cachestaleonerror">CacheStaleOnError</a></li>
<li><a href="mod_cache.html#cachestoreexpired">CacheStoreExpired</a></li>
<li><a href="mod_cache.html#cachestorenostore">CacheStoreNoStore</a></li>
<li><a href="mod_cache.html#cachestoreprivate">CacheStorePrivate</a></li>
<li><a href="mod_cgid.html#cgidscripttimeout">CGIDScriptTimeout</a></li>
<li><a href="core.html#cgimapextension">CGIMapExtension</a></li>
<li><a href="core.html#cgipassauth">CGIPassAuth</a></li>
<li><a href="mod_cgi.html#cgiscripttimeout">CGIScriptTimeout</a></li>
<li><a href="core.html#cgivar">CGIVar</a></li>
<li><a href="mod_charset_lite.html#charsetdefault">CharsetDefault</a></li>
<li><a href="mod_charset_lite.html#charsetoptions">CharsetOptions</a></li>
<li><a href="mod_charset_lite.html#charsetsourceenc">CharsetSourceEnc</a></li>
<li><a href="mod_speling.html#checkbasenamematch">CheckBasenameMatch</a></li>
<li><a href="mod_speling.html#checkcaseonly">CheckCaseOnly</a></li>
<li><a href="mod_speling.html#checkspelling">CheckSpelling</a></li>
<li><a href="mod_unixd.html#chrootdir">ChrootDir</a></li>
<li><a href="core.html#contentdigest">ContentDigest</a></li>
<li><a href="mod_usertrack.html#cookiedomain">CookieDomain</a></li>
<li><a href="mod_usertrack.html#cookieexpires">CookieExpires</a></li>
<li><a href="mod_usertrack.html#cookiehttponly">CookieHTTPOnly</a></li>
<li><a href="mod_usertrack.html#cookiename">CookieName</a></li>
<li><a href="mod_usertrack.html#cookiesamesite">CookieSameSite</a></li>
<li><a href="mod_usertrack.html#cookiesecure">CookieSecure</a></li>
<li><a href="mod_usertrack.html#cookiestyle">CookieStyle</a></li>
<li><a href="mod_usertrack.html#cookietracking">CookieTracking</a></li>
<li><a href="mpm_common.html#coredumpdirectory">CoreDumpDirectory</a></li>
<li><a href="mod_log_config.html#customlog">CustomLog</a></li>
<li><a href="mod_dav.html#dav" id="D" name="D">Dav</a></li>
<li><a href="mod_dav.html#davbasepath">DavBasePath</a></li>
<li><a href="mod_dav.html#davdepthinfinity">DavDepthInfinity</a></li>
<li><a href="mod_dav_lock.html#davgenericlockdb">DavGenericLockDB</a></li>
<li><a href="mod_dav_fs.html#davlockdb">DavLockDB</a></li>
<li><a href="mod_dav_fs.html#davlockdiscovery">DavLockDiscovery</a></li>
<li><a href="mod_dav.html#davmintimeout">DavMinTimeout</a></li>
<li><a href="mod_dbd.html#dbdexptime">DBDExptime</a></li>
<li><a href="mod_dbd.html#dbdinitsql">DBDInitSQL</a></li>
<li><a href="mod_dbd.html#dbdkeep">DBDKeep</a></li>
<li><a href="mod_dbd.html#dbdmax">DBDMax</a></li>
<li><a href="mod_dbd.html#dbdmin">DBDMin</a></li>
<li><a href="mod_dbd.html#dbdparams">DBDParams</a></li>
<li><a href="mod_dbd.html#dbdpersist">DBDPersist</a></li>
<li><a href="mod_dbd.html#dbdpreparesql">DBDPrepareSQL</a></li>
<li><a href="mod_dbd.html#dbdriver">DBDriver</a></li>
<li><a href="mod_autoindex.html#defaulticon">DefaultIcon</a></li>
<li><a href="mod_mime.html#defaultlanguage">DefaultLanguage</a></li>
<li><a href="core.html#defaultruntimedir">DefaultRuntimeDir</a></li>
<li><a href="core.html#defaulttype">DefaultType</a></li>
<li><a href="core.html#define">Define</a></li>
<li><a href="mod_deflate.html#deflatealteretag">DeflateAlterETag</a></li>
<li><a href="mod_deflate.html#deflatebuffersize">DeflateBufferSize</a></li>
<li><a href="mod_deflate.html#deflatecompressionlevel">DeflateCompressionLevel</a></li>
<li><a href="mod_deflate.html#deflatefilternote">DeflateFilterNote</a></li>
<li><a href="mod_deflate.html#deflateinflatelimitrequestbody">DeflateInflateLimitRequestBody</a></li>
<li><a href="mod_deflate.html#deflateinflateratioburst">DeflateInflateRatioBurst</a></li>
<li><a href="mod_deflate.html#deflateinflateratiolimit">DeflateInflateRatioLimit</a></li>
<li><a href="mod_deflate.html#deflatememlevel">DeflateMemLevel</a></li>
<li><a href="mod_deflate.html#deflatewindowsize">DeflateWindowSize</a></li>
<li><a href="mod_access_compat.html#deny">Deny</a></li>
<li><a href="core.html#directory">&lt;Directory&gt;</a></li>
<li><a href="mod_dir.html#directorycheckhandler">DirectoryCheckHandler</a></li>
<li><a href="mod_dir.html#directoryindex">DirectoryIndex</a></li>
<li><a href="mod_dir.html#directoryindexredirect">DirectoryIndexRedirect</a></li>
<li><a href="core.html#directorymatch">&lt;DirectoryMatch&gt;</a></li>
<li><a href="mod_dir.html#directoryslash">DirectorySlash</a></li>
<li><a href="core.html#documentroot">DocumentRoot</a></li>
<li><a href="mod_privileges.html#dtraceprivileges">DTracePrivileges</a></li>
<li><a href="mod_dumpio.html#dumpioinput">DumpIOInput</a></li>
<li><a href="mod_dumpio.html#dumpiooutput">DumpIOOutput</a></li>
<li><a href="core.html#else" id="E" name="E">&lt;Else&gt;</a></li>
<li><a href="core.html#elseif">&lt;ElseIf&gt;</a></li>
<li><a href="mpm_common.html#enableexceptionhook">EnableExceptionHook</a></li>
<li><a href="core.html#enablemmap">EnableMMAP</a></li>
<li><a href="core.html#enablesendfile">EnableSendfile</a></li>
<li><a href="core.html#error">Error</a></li>
<li><a href="core.html#errordocument">ErrorDocument</a></li>
<li><a href="core.html#errorlog">ErrorLog</a></li>
<li><a href="core.html#errorlogformat">ErrorLogFormat</a></li>
<li><a href="mod_example_hooks.html#example">Example</a></li>
<li><a href="mod_expires.html#expiresactive">ExpiresActive</a></li>
<li><a href="mod_expires.html#expiresbytype">ExpiresByType</a></li>
<li><a href="mod_expires.html#expiresdefault">ExpiresDefault</a></li>
<li><a href="core.html#extendedstatus">ExtendedStatus</a></li>
<li><a href="mod_ext_filter.html#extfilterdefine">ExtFilterDefine</a></li>
<li><a href="mod_ext_filter.html#extfilteroptions">ExtFilterOptions</a></li>
<li><a href="mod_dir.html#fallbackresource" id="F" name="F">FallbackResource</a></li>
<li><a href="core.html#fileetag">FileETag</a></li>
<li><a href="core.html#files">&lt;Files&gt;</a></li>
<li><a href="core.html#filesmatch">&lt;FilesMatch&gt;</a></li>
<li><a href="mod_filter.html#filterchain">FilterChain</a></li>
<li><a href="mod_filter.html#filterdeclare">FilterDeclare</a></li>
<li><a href="mod_filter.html#filterprotocol">FilterProtocol</a></li>
<li><a href="mod_filter.html#filterprovider">FilterProvider</a></li>
<li><a href="mod_filter.html#filtertrace">FilterTrace</a></li>
<li><a href="core.html#flushmaxpipelined">FlushMaxPipelined</a></li>
<li><a href="core.html#flushmaxthreshold">FlushMaxThreshold</a></li>
<li><a href="mod_negotiation.html#forcelanguagepriority">ForceLanguagePriority</a></li>
<li><a href="core.html#forcetype">ForceType</a></li>
<li><a href="mod_log_forensic.html#forensiclog">ForensicLog</a></li>
<li><a href="mod_log_config.html#globallog" id="G" name="G">GlobalLog</a></li>
<li><a href="core.html#gprofdir">GprofDir</a></li>
<li><a href="mpm_common.html#gracefulshutdowntimeout">GracefulShutdownTimeout</a></li>
<li><a href="mod_unixd.html#group">Group</a></li>
<li><a href="mod_http2.html#h2copyfiles" id="H" name="H">H2CopyFiles</a></li>
<li><a href="mod_http2.html#h2direct">H2Direct</a></li>
<li><a href="mod_http2.html#h2earlyhint">H2EarlyHint</a></li>
<li><a href="mod_http2.html#h2earlyhints">H2EarlyHints</a></li>
<li><a href="mod_http2.html#h2maxdataframelen">H2MaxDataFrameLen</a></li>
<li><a href="mod_http2.html#h2maxheaderblocklen">H2MaxHeaderBlockLen</a></li>
<li><a href="mod_http2.html#h2maxsessionstreams">H2MaxSessionStreams</a></li>
<li><a href="mod_http2.html#h2maxstreamerrors">H2MaxStreamErrors</a></li>
<li><a href="mod_http2.html#h2maxworkeridleseconds">H2MaxWorkerIdleSeconds</a></li>
<li><a href="mod_http2.html#h2maxworkers">H2MaxWorkers</a></li>
<li><a href="mod_http2.html#h2minworkers">H2MinWorkers</a></li>
<li><a href="mod_http2.html#h2moderntlsonly">H2ModernTLSOnly</a></li>
<li><a href="mod_http2.html#h2outputbuffering">H2OutputBuffering</a></li>
<li><a href="mod_http2.html#h2padding">H2Padding</a></li>
<li><a href="mod_http2.html#h2proxyrequests">H2ProxyRequests</a></li>
<li><a href="mod_http2.html#h2push">H2Push</a></li>
<li><a href="mod_http2.html#h2pushdiarysize">H2PushDiarySize</a></li>
<li><a href="mod_http2.html#h2pushpriority">H2PushPriority</a></li>
<li><a href="mod_http2.html#h2pushresource">H2PushResource</a></li>
<li><a href="mod_http2.html#h2serializeheaders">H2SerializeHeaders</a></li>
<li><a href="mod_http2.html#h2streammaxmemsize">H2StreamMaxMemSize</a></li>
<li><a href="mod_http2.html#h2streamtimeout">H2StreamTimeout</a></li>
<li><a href="mod_http2.html#h2tlscooldownsecs">H2TLSCoolDownSecs</a></li>
<li><a href="mod_http2.html#h2tlswarmupsize">H2TLSWarmUpSize</a></li>
<li><a href="mod_http2.html#h2upgrade">H2Upgrade</a></li>
<li><a href="mod_http2.html#h2websockets">H2WebSockets</a></li>
<li><a href="mod_http2.html#h2windowsize">H2WindowSize</a></li>
<li><a href="mod_headers.html#header">Header</a></li>
<li><a href="mod_autoindex.html#headername">HeaderName</a></li>
<li><a href="mod_heartbeat.html#heartbeataddress">HeartbeatAddress</a></li>
<li><a href="mod_heartmonitor.html#heartbeatlisten">HeartbeatListen</a></li>
<li><a href="mod_heartmonitor.html#heartbeatmaxservers">HeartbeatMaxServers</a></li>
<li><a href="mod_heartmonitor.html#heartbeatstorage">HeartbeatStorage</a></li>
<li><a href="mod_lbmethod_heartbeat.html#heartbeatstorage">HeartbeatStorage</a></li>
<li><a href="core.html#hostnamelookups">HostnameLookups</a></li>
<li><a href="core.html#httpprotocoloptions">HttpProtocolOptions</a></li>
<li><a href="mod_ident.html#identitycheck" id="I" name="I">IdentityCheck</a></li>
<li><a href="mod_ident.html#identitychecktimeout">IdentityCheckTimeout</a></li>
<li><a href="core.html#if">&lt;If&gt;</a></li>
<li><a href="core.html#ifdefine">&lt;IfDefine&gt;</a></li>
<li><a href="core.html#ifdirective">&lt;IfDirective&gt;</a></li>
<li><a href="core.html#iffile">&lt;IfFile&gt;</a></li>
<li><a href="core.html#ifmodule">&lt;IfModule&gt;</a></li>
<li><a href="core.html#ifsection">&lt;IfSection&gt;</a></li>
<li><a href="mod_version.html#ifversion">&lt;IfVersion&gt;</a></li>
<li><a href="mod_imagemap.html#imapbase">ImapBase</a></li>
<li><a href="mod_imagemap.html#imapdefault">ImapDefault</a></li>
<li><a href="mod_imagemap.html#imapmenu">ImapMenu</a></li>
<li><a href="core.html#include">Include</a></li>
<li><a href="core.html#includeoptional">IncludeOptional</a></li>
<li><a href="mod_autoindex.html#indexheadinsert">IndexHeadInsert</a></li>
<li><a href="mod_autoindex.html#indexignore">IndexIgnore</a></li>
<li><a href="mod_autoindex.html#indexignorereset">IndexIgnoreReset</a></li>
<li><a href="mod_autoindex.html#indexoptions">IndexOptions</a></li>
<li><a href="mod_autoindex.html#indexorderdefault">IndexOrderDefault</a></li>
<li><a href="mod_autoindex.html#indexstylesheet">IndexStyleSheet</a></li>
<li><a href="mod_sed.html#inputsed">InputSed</a></li>
<li><a href="mod_isapi.html#isapiappendlogtoerrors">ISAPIAppendLogToErrors</a></li>
<li><a href="mod_isapi.html#isapiappendlogtoquery">ISAPIAppendLogToQuery</a></li>
<li><a href="mod_isapi.html#isapicachefile">ISAPICacheFile</a></li>
<li><a href="mod_isapi.html#isapifakeasync">ISAPIFakeAsync</a></li>
<li><a href="mod_isapi.html#isapilognotsupported">ISAPILogNotSupported</a></li>
<li><a href="mod_isapi.html#isapireadaheadbuffer">ISAPIReadAheadBuffer</a></li>
<li><a href="core.html#keepalive" id="K" name="K">KeepAlive</a></li>
<li><a href="core.html#keepalivetimeout">KeepAliveTimeout</a></li>
<li><a href="mod_request.html#keptbodysize">KeptBodySize</a></li>
<li><a href="mod_negotiation.html#languagepriority" id="L" name="L">LanguagePriority</a></li>
<li><a href="mod_ldap.html#ldapcacheentries">LDAPCacheEntries</a></li>
<li><a href="mod_ldap.html#ldapcachettl">LDAPCacheTTL</a></li>
<li><a href="mod_ldap.html#ldapconnectionpoolttl">LDAPConnectionPoolTTL</a></li>
<li><a href="mod_ldap.html#ldapconnectiontimeout">LDAPConnectionTimeout</a></li>
<li><a href="mod_ldap.html#ldaplibrarydebug">LDAPLibraryDebug</a></li>
<li><a href="mod_ldap.html#ldapopcacheentries">LDAPOpCacheEntries</a></li>
<li><a href="mod_ldap.html#ldapopcachettl">LDAPOpCacheTTL</a></li>
<li><a href="mod_ldap.html#ldapreferralhoplimit">LDAPReferralHopLimit</a></li>
<li><a href="mod_ldap.html#ldapreferrals">LDAPReferrals</a></li>
<li><a href="mod_ldap.html#ldapretries">LDAPRetries</a></li>
<li><a href="mod_ldap.html#ldapretrydelay">LDAPRetryDelay</a></li>
<li><a href="mod_ldap.html#ldapsharedcachefile">LDAPSharedCacheFile</a></li>
<li><a href="mod_ldap.html#ldapsharedcachesize">LDAPSharedCacheSize</a></li>
<li><a href="mod_ldap.html#ldaptimeout">LDAPTimeout</a></li>
<li><a href="mod_ldap.html#ldaptrustedclientcert">LDAPTrustedClientCert</a></li>
<li><a href="mod_ldap.html#ldaptrustedglobalcert">LDAPTrustedGlobalCert</a></li>
<li><a href="mod_ldap.html#ldaptrustedmode">LDAPTrustedMode</a></li>
<li><a href="mod_ldap.html#ldapverifyservercert">LDAPVerifyServerCert</a></li>
<li><a href="core.html#limit">&lt;Limit&gt;</a></li>
<li><a href="core.html#limitexcept">&lt;LimitExcept&gt;</a></li>
<li><a href="core.html#limitinternalrecursion">LimitInternalRecursion</a></li>
<li><a href="core.html#limitrequestbody">LimitRequestBody</a></li>
<li><a href="core.html#limitrequestfields">LimitRequestFields</a></li>
<li><a href="core.html#limitrequestfieldsize">LimitRequestFieldSize</a></li>
<li><a href="core.html#limitrequestline">LimitRequestLine</a></li>
<li><a href="core.html#limitxmlrequestbody">LimitXMLRequestBody</a></li>
<li><a href="mpm_common.html#listen">Listen</a></li>
<li><a href="mpm_common.html#listenbacklog">ListenBackLog</a></li>
<li><a href="mpm_common.html#listencoresbucketsratio">ListenCoresBucketsRatio</a></li>
<li><a href="mpm_common.html#listentcpdeferaccept">ListenTCPDeferAccept</a></li>
<li><a href="mod_so.html#loadfile">LoadFile</a></li>
<li><a href="mod_so.html#loadmodule">LoadModule</a></li>
<li><a href="core.html#location">&lt;Location&gt;</a></li>
<li><a href="core.html#locationmatch">&lt;LocationMatch&gt;</a></li>
<li><a href="mod_log_config.html#logformat">LogFormat</a></li>
<li><a href="mod_logio.html#logiotrackttfb">LogIOTrackTTFB</a></li>
<li><a href="core.html#loglevel">LogLevel</a></li>
<li><a href="mod_log_debug.html#logmessage">LogMessage</a></li>
<li><a href="mod_lua.html#luaauthzprovider">LuaAuthzProvider</a></li>
<li><a href="mod_lua.html#luacodecache">LuaCodeCache</a></li>
<li><a href="mod_lua.html#luahookaccesschecker">LuaHookAccessChecker</a></li>
<li><a href="mod_lua.html#luahookauthchecker">LuaHookAuthChecker</a></li>
<li><a href="mod_lua.html#luahookcheckuserid">LuaHookCheckUserID</a></li>
<li><a href="mod_lua.html#luahookfixups">LuaHookFixups</a></li>
<li><a href="mod_lua.html#luahookinsertfilter">LuaHookInsertFilter</a></li>
<li><a href="mod_lua.html#luahooklog">LuaHookLog</a></li>
<li><a href="mod_lua.html#luahookmaptostorage">LuaHookMapToStorage</a></li>
<li><a href="mod_lua.html#luahookpretranslate">LuaHookPreTranslate</a></li>
<li><a href="mod_lua.html#luahooktranslatename">LuaHookTranslateName</a></li>
<li><a href="mod_lua.html#luahooktypechecker">LuaHookTypeChecker</a></li>
<li><a href="mod_lua.html#luainherit">LuaInherit</a></li>
<li><a href="mod_lua.html#luainputfilter">LuaInputFilter</a></li>
<li><a href="mod_lua.html#luamaphandler">LuaMapHandler</a></li>
<li><a href="mod_lua.html#luaoutputfilter">LuaOutputFilter</a></li>
<li><a href="mod_lua.html#luapackagecpath">LuaPackageCPath</a></li>
<li><a href="mod_lua.html#luapackagepath">LuaPackagePath</a></li>
<li><a href="mod_lua.html#luaquickhandler">LuaQuickHandler</a></li>
<li><a href="mod_lua.html#luaroot">LuaRoot</a></li>
<li><a href="mod_lua.html#luascope">LuaScope</a></li>
<li><a href="mod_macro.html#macro" id="M" name="M">&lt;Macro&gt;</a></li>
<li><a href="mpm_common.html#maxconnectionsperchild">MaxConnectionsPerChild</a></li>
<li><a href="core.html#maxkeepaliverequests">MaxKeepAliveRequests</a></li>
<li><a href="mpm_common.html#maxmemfree">MaxMemFree</a></li>
<li><a href="core.html#maxrangeoverlaps">MaxRangeOverlaps</a></li>
<li><a href="core.html#maxrangereversals">MaxRangeReversals</a></li>
<li><a href="core.html#maxranges">MaxRanges</a></li>
<li><a href="mpm_common.html#maxrequestworkers">MaxRequestWorkers</a></li>
<li><a href="prefork.html#maxspareservers">MaxSpareServers</a></li>
<li><a href="mpm_common.html#maxsparethreads">MaxSpareThreads</a></li>
<li><a href="mpm_netware.html#maxthreads">MaxThreads</a></li>
<li><a href="mod_md.html#mdactivationdelay">MDActivationDelay</a></li>
<li><a href="mod_md.html#mdbaseserver">MDBaseServer</a></li>
<li><a href="mod_md.html#mdcachallenges">MDCAChallenges</a></li>
<li><a href="mod_md.html#mdcertificateagreement">MDCertificateAgreement</a></li>
<li><a href="mod_md.html#mdcertificateauthority">MDCertificateAuthority</a></li>
<li><a href="mod_md.html#mdcertificatecheck">MDCertificateCheck</a></li>
<li><a href="mod_md.html#mdcertificatefile">MDCertificateFile</a></li>
<li><a href="mod_md.html#mdcertificatekeyfile">MDCertificateKeyFile</a></li>
<li><a href="mod_md.html#mdcertificatemonitor">MDCertificateMonitor</a></li>
<li><a href="mod_md.html#mdcertificateprotocol">MDCertificateProtocol</a></li>
<li><a href="mod_md.html#mdcertificatestatus">MDCertificateStatus</a></li>
<li><a href="mod_md.html#mdchallengedns01">MDChallengeDns01</a></li>
<li><a href="mod_md.html#mdchallengedns01version">MDChallengeDns01Version</a></li>
<li><a href="mod_md.html#mdcheckinterval">MDCheckInterval</a></li>
<li><a href="mod_md.html#mdcontactemail">MDContactEmail</a></li>
<li><a href="mod_md.html#mddrivemode">MDDriveMode</a></li>
<li><a href="mod_md.html#mdexternalaccountbinding">MDExternalAccountBinding</a></li>
<li><a href="mod_md.html#mdhttpproxy">MDHttpProxy</a></li>
<li><a href="mod_md.html#mdinitialdelay">MDInitialDelay</a></li>
<li><a href="mod_md.html#mdmatchnames">MDMatchNames</a></li>
<li><a href="mod_md.html#mdmember">MDMember</a></li>
<li><a href="mod_md.html#mdmembers">MDMembers</a></li>
<li><a href="mod_md.html#mdmessagecmd">MDMessageCmd</a></li>
<li><a href="mod_md.html#mdmuststaple">MDMustStaple</a></li>
<li><a href="mod_md.html#mdnotifycmd">MDNotifyCmd</a></li>
<li><a href="mod_md.html#mdomain">MDomain</a></li>
<li><a href="mod_md.html#mdomainset">&lt;MDomainSet&gt;</a></li>
<li><a href="mod_md.html#mdportmap">MDPortMap</a></li>
<li><a href="mod_md.html#mdprivatekeys">MDPrivateKeys</a></li>
<li><a href="mod_md.html#mdprofile">MDProfile</a></li>
<li><a href="mod_md.html#mdprofilemandatory">MDProfileMandatory</a></li>
<li><a href="mod_md.html#mdrenewmode">MDRenewMode</a></li>
<li><a href="mod_md.html#mdrenewviaari">MDRenewViaARI</a></li>
<li><a href="mod_md.html#mdrenewwindow">MDRenewWindow</a></li>
<li><a href="mod_md.html#mdrequirehttps">MDRequireHttps</a></li>
<li><a href="mod_md.html#mdretrydelay">MDRetryDelay</a></li>
<li><a href="mod_md.html#mdretryfailover">MDRetryFailover</a></li>
<li><a href="mod_md.html#mdserverstatus">MDServerStatus</a></li>
<li><a href="mod_md.html#mdstapleothers">MDStapleOthers</a></li>
<li><a href="mod_md.html#mdstapling">MDStapling</a></li>
<li><a href="mod_md.html#mdstaplingkeepresponse">MDStaplingKeepResponse</a></li>
<li><a href="mod_md.html#mdstaplingrenewwindow">MDStaplingRenewWindow</a></li>
<li><a href="mod_md.html#mdstoredir">MDStoreDir</a></li>
<li><a href="mod_md.html#mdstorelocks">MDStoreLocks</a></li>
<li><a href="mod_md.html#mdwarnwindow">MDWarnWindow</a></li>
<li><a href="mod_socache_memcache.html#memcacheconnttl">MemcacheConnTTL</a></li>
<li><a href="core.html#mergeslashes">MergeSlashes</a></li>
<li><a href="core.html#mergetrailers">MergeTrailers</a></li>
<li><a href="mod_cern_meta.html#metadir">MetaDir</a></li>
<li><a href="mod_cern_meta.html#metafiles">MetaFiles</a></li>
<li><a href="mod_cern_meta.html#metasuffix">MetaSuffix</a></li>
<li><a href="mod_mime_magic.html#mimemagicfile">MimeMagicFile</a></li>
<li><a href="prefork.html#minspareservers">MinSpareServers</a></li>
<li><a href="mpm_common.html#minsparethreads">MinSpareThreads</a></li>
<li><a href="mod_file_cache.html#mmapfile">MMapFile</a></li>
<li><a href="mod_dialup.html#modemstandard">ModemStandard</a></li>
<li><a href="mod_mime.html#modmimeusepathinfo">ModMimeUsePathInfo</a></li>
<li><a href="mod_mime.html#multiviewsmatch">MultiviewsMatch</a></li>
<li><a href="core.html#mutex">Mutex</a></li>
<li><a href="core.html#namevirtualhost" id="N" name="N">NameVirtualHost</a></li>
<li><a href="mod_proxy.html#noproxy">NoProxy</a></li>
<li><a href="mod_nw_ssl.html#nwssltrustedcerts">NWSSLTrustedCerts</a></li>
<li><a href="mod_nw_ssl.html#nwsslupgradeable">NWSSLUpgradeable</a></li>
<li><a href="core.html#options" id="O" name="O">Options</a></li>
<li><a href="mod_access_compat.html#order">Order</a></li>
<li><a href="mod_sed.html#outputsed">OutputSed</a></li>
<li><a href="mod_env.html#passenv" id="P" name="P">PassEnv</a></li>
<li><a href="mpm_common.html#pidfile">PidFile</a></li>
<li><a href="mod_privileges.html#privilegesmode">PrivilegesMode</a></li>
<li><a href="core.html#protocol">Protocol</a></li>
<li><a href="mod_echo.html#protocolecho">ProtocolEcho</a></li>
<li><a href="core.html#protocols">Protocols</a></li>
<li><a href="core.html#protocolshonororder">ProtocolsHonorOrder</a></li>
<li><a href="mod_proxy.html#proxy">&lt;Proxy&gt;</a></li>
<li><a href="mod_proxy.html#proxy100continue">Proxy100Continue</a></li>
<li><a href="mod_proxy.html#proxyaddheaders">ProxyAddHeaders</a></li>
<li><a href="mod_proxy.html#proxybadheader">ProxyBadHeader</a></li>
<li><a href="mod_proxy.html#proxyblock">ProxyBlock</a></li>
<li><a href="mod_proxy.html#proxydomain">ProxyDomain</a></li>
<li><a href="mod_proxy.html#proxyerroroverride">ProxyErrorOverride</a></li>
<li><a href="mod_proxy_express.html#proxyexpressdbmfile">ProxyExpressDBMFile</a></li>
<li><a href="mod_proxy_express.html#proxyexpressdbmtype">ProxyExpressDBMType</a></li>
<li><a href="mod_proxy_express.html#proxyexpressenable">ProxyExpressEnable</a></li>
<li><a href="mod_proxy_fcgi.html#proxyfcgibackendtype">ProxyFCGIBackendType</a></li>
<li><a href="mod_proxy_fcgi.html#proxyfcgisetenvif">ProxyFCGISetEnvIf</a></li>
<li><a href="mod_proxy_ftp.html#proxyftpdircharset">ProxyFtpDirCharset</a></li>
<li><a href="mod_proxy_ftp.html#proxyftpescapewildcards">ProxyFtpEscapeWildcards</a></li>
<li><a href="mod_proxy_ftp.html#proxyftplistonwildcard">ProxyFtpListOnWildcard</a></li>
<li><a href="mod_proxy_hcheck.html#proxyhcexpr">ProxyHCExpr</a></li>
<li><a href="mod_proxy_hcheck.html#proxyhctemplate">ProxyHCTemplate</a></li>
<li><a href="mod_proxy_hcheck.html#proxyhctpsize">ProxyHCTPsize</a></li>
<li><a href="mod_proxy_html.html#proxyhtmlbufsize">ProxyHTMLBufSize</a></li>
<li><a href="mod_proxy_html.html#proxyhtmlcharsetout">ProxyHTMLCharsetOut</a></li>
<li><a href="mod_proxy_html.html#proxyhtmldoctype">ProxyHTMLDocType</a></li>
<li><a href="mod_proxy_html.html#proxyhtmlenable">ProxyHTMLEnable</a></li>
<li><a href="mod_proxy_html.html#proxyhtmlevents">ProxyHTMLEvents</a></li>
<li><a href="mod_proxy_html.html#proxyhtmlextended">ProxyHTMLExtended</a></li>
<li><a href="mod_proxy_html.html#proxyhtmlfixups">ProxyHTMLFixups</a></li>
<li><a href="mod_proxy_html.html#proxyhtmlinterp">ProxyHTMLInterp</a></li>
<li><a href="mod_proxy_html.html#proxyhtmllinks">ProxyHTMLLinks</a></li>
<li><a href="mod_proxy_html.html#proxyhtmlmeta">ProxyHTMLMeta</a></li>
<li><a href="mod_proxy_html.html#proxyhtmlstripcomments">ProxyHTMLStripComments</a></li>
<li><a href="mod_proxy_html.html#proxyhtmlurlmap">ProxyHTMLURLMap</a></li>
<li><a href="mod_proxy.html#proxyiobuffersize">ProxyIOBufferSize</a></li>
<li><a href="mod_proxy.html#proxymatch">&lt;ProxyMatch&gt;</a></li>
<li><a href="mod_proxy.html#proxymaxforwards">ProxyMaxForwards</a></li>
<li><a href="mod_proxy.html#proxypass">ProxyPass</a></li>
<li><a href="mod_proxy.html#proxypassinherit">ProxyPassInherit</a></li>
<li><a href="mod_proxy.html#proxypassinterpolateenv">ProxyPassInterpolateEnv</a></li>
<li><a href="mod_proxy.html#proxypassmatch">ProxyPassMatch</a></li>
<li><a href="mod_proxy.html#proxypassreverse">ProxyPassReverse</a></li>
<li><a href="mod_proxy.html#proxypassreversecookiedomain">ProxyPassReverseCookieDomain</a></li>
<li><a href="mod_proxy.html#proxypassreversecookiepath">ProxyPassReverseCookiePath</a></li>
<li><a href="mod_proxy.html#proxypreservehost">ProxyPreserveHost</a></li>
<li><a href="mod_proxy.html#proxyreceivebuffersize">ProxyReceiveBufferSize</a></li>
<li><a href="mod_proxy.html#proxyremote">ProxyRemote</a></li>
<li><a href="mod_proxy.html#proxyremotematch">ProxyRemoteMatch</a></li>
<li><a href="mod_proxy.html#proxyrequests">ProxyRequests</a></li>
<li><a href="mod_proxy_scgi.html#proxyscgiinternalredirect">ProxySCGIInternalRedirect</a></li>
<li><a href="mod_proxy_scgi.html#proxyscgisendfile">ProxySCGISendfile</a></li>
<li><a href="mod_proxy.html#proxyset">ProxySet</a></li>
<li><a href="mod_proxy.html#proxysourceaddress">ProxySourceAddress</a></li>
<li><a href="mod_proxy.html#proxystatus">ProxyStatus</a></li>
<li><a href="mod_proxy.html#proxytimeout">ProxyTimeout</a></li>
<li><a href="mod_proxy.html#proxyvia">ProxyVia</a></li>
<li><a href="mod_proxy_wstunnel.html#proxywebsocketfallbacktoproxyhttp">ProxyWebsocketFallbackToProxyHttp</a></li>
<li><a href="core.html#qualifyredirecturl" id="Q" name="Q">QualifyRedirectURL</a></li>
<li><a href="core.html#readbuffersize" id="R" name="R">ReadBufferSize</a></li>
<li><a href="mod_autoindex.html#readmename">ReadmeName</a></li>
<li><a href="mpm_common.html#receivebuffersize">ReceiveBufferSize</a></li>
<li><a href="mod_alias.html#redirect">Redirect</a></li>
<li><a href="mod_alias.html#redirectmatch">RedirectMatch</a></li>
<li><a href="mod_alias.html#redirectpermanent">RedirectPermanent</a></li>
<li><a href="mod_alias.html#redirectrelative">RedirectRelative</a></li>
<li><a href="mod_alias.html#redirecttemp">RedirectTemp</a></li>
<li><a href="mod_socache_redis.html#redisconnpoolttl">RedisConnPoolTTL</a></li>
<li><a href="mod_socache_redis.html#redistimeout">RedisTimeout</a></li>
<li><a href="mod_reflector.html#reflectorheader">ReflectorHeader</a></li>
<li><a href="core.html#regexdefaultoptions">RegexDefaultOptions</a></li>
<li><a href="core.html#registerhttpmethod">RegisterHttpMethod</a></li>
<li><a href="mod_remoteip.html#remoteipheader">RemoteIPHeader</a></li>
<li><a href="mod_remoteip.html#remoteipinternalproxy">RemoteIPInternalProxy</a></li>
<li><a href="mod_remoteip.html#remoteipinternalproxylist">RemoteIPInternalProxyList</a></li>
<li><a href="mod_remoteip.html#remoteipproxiesheader">RemoteIPProxiesHeader</a></li>
<li><a href="mod_remoteip.html#remoteipproxyprotocol">RemoteIPProxyProtocol</a></li>
<li><a href="mod_remoteip.html#remoteipproxyprotocolexceptions">RemoteIPProxyProtocolExceptions</a></li>
<li><a href="mod_remoteip.html#remoteiptrustedproxy">RemoteIPTrustedProxy</a></li>
<li><a href="mod_remoteip.html#remoteiptrustedproxylist">RemoteIPTrustedProxyList</a></li>
<li><a href="mod_mime.html#removecharset">RemoveCharset</a></li>
<li><a href="mod_mime.html#removeencoding">RemoveEncoding</a></li>
<li><a href="mod_mime.html#removehandler">RemoveHandler</a></li>
<li><a href="mod_mime.html#removeinputfilter">RemoveInputFilter</a></li>
<li><a href="mod_mime.html#removelanguage">RemoveLanguage</a></li>
<li><a href="mod_mime.html#removeoutputfilter">RemoveOutputFilter</a></li>
<li><a href="mod_mime.html#removetype">RemoveType</a></li>
<li><a href="mod_headers.html#requestheader">RequestHeader</a></li>
<li><a href="mod_reqtimeout.html#requestreadtimeout">RequestReadTimeout</a></li>
<li><a href="mod_authz_core.html#require">Require</a></li>
<li><a href="mod_authz_core.html#requireall">&lt;RequireAll&gt;</a></li>
<li><a href="mod_authz_core.html#requireany">&lt;RequireAny&gt;</a></li>
<li><a href="mod_authz_core.html#requirenone">&lt;RequireNone&gt;</a></li>
<li><a href="mod_rewrite.html#rewritebase">RewriteBase</a></li>
<li><a href="mod_rewrite.html#rewritecond">RewriteCond</a></li>
<li><a href="mod_rewrite.html#rewriteengine">RewriteEngine</a></li>
<li><a href="mod_rewrite.html#rewritemap">RewriteMap</a></li>
<li><a href="mod_rewrite.html#rewriteoptions">RewriteOptions</a></li>
<li><a href="mod_rewrite.html#rewriterule">RewriteRule</a></li>
<li><a href="core.html#rlimitcpu">RLimitCPU</a></li>
<li><a href="core.html#rlimitmem">RLimitMEM</a></li>
<li><a href="core.html#rlimitnproc">RLimitNPROC</a></li>
<li><a href="mod_access_compat.html#satisfy" id="S" name="S">Satisfy</a></li>
<li><a href="mpm_common.html#scoreboardfile">ScoreBoardFile</a></li>
<li><a href="mod_actions.html#script">Script</a></li>
<li><a href="mod_alias.html#scriptalias">ScriptAlias</a></li>
<li><a href="mod_alias.html#scriptaliasmatch">ScriptAliasMatch</a></li>
<li><a href="core.html#scriptinterpretersource">ScriptInterpreterSource</a></li>
<li><a href="mod_cgi.html#scriptlog">ScriptLog</a></li>
<li><a href="mod_cgi.html#scriptlogbuffer">ScriptLogBuffer</a></li>
<li><a href="mod_cgi.html#scriptloglength">ScriptLogLength</a></li>
<li><a href="mod_cgid.html#scriptsock">ScriptSock</a></li>
<li><a href="mod_nw_ssl.html#securelisten">SecureListen</a></li>
<li><a href="core.html#seerequesttail">SeeRequestTail</a></li>
<li><a href="mpm_common.html#sendbuffersize">SendBufferSize</a></li>
<li><a href="core.html#serveradmin">ServerAdmin</a></li>
<li><a href="core.html#serveralias">ServerAlias</a></li>
<li><a href="mpm_common.html#serverlimit">ServerLimit</a></li>
<li><a href="core.html#servername">ServerName</a></li>
<li><a href="core.html#serverpath">ServerPath</a></li>
<li><a href="core.html#serverroot">ServerRoot</a></li>
<li><a href="core.html#serversignature">ServerSignature</a></li>
<li><a href="core.html#servertokens">ServerTokens</a></li>
<li><a href="mod_session.html#session">Session</a></li>
<li><a href="mod_session_cookie.html#sessioncookiename">SessionCookieName</a></li>
<li><a href="mod_session_cookie.html#sessioncookiename2">SessionCookieName2</a></li>
<li><a href="mod_session_cookie.html#sessioncookieremove">SessionCookieRemove</a></li>
<li><a href="mod_session_crypto.html#sessioncryptocipher">SessionCryptoCipher</a></li>
<li><a href="mod_session_crypto.html#sessioncryptodriver">SessionCryptoDriver</a></li>
<li><a href="mod_session_crypto.html#sessioncryptopassphrase">SessionCryptoPassphrase</a></li>
<li><a href="mod_session_crypto.html#sessioncryptopassphrasefile">SessionCryptoPassphraseFile</a></li>
<li><a href="mod_session_dbd.html#sessiondbdcookiename">SessionDBDCookieName</a></li>
<li><a href="mod_session_dbd.html#sessiondbdcookiename2">SessionDBDCookieName2</a></li>
<li><a href="mod_session_dbd.html#sessiondbdcookieremove">SessionDBDCookieRemove</a></li>
<li><a href="mod_session_dbd.html#sessiondbddeletelabel">SessionDBDDeleteLabel</a></li>
<li><a href="mod_session_dbd.html#sessiondbdinsertlabel">SessionDBDInsertLabel</a></li>
<li><a href="mod_session_dbd.html#sessiondbdperuser">SessionDBDPerUser</a></li>
<li><a href="mod_session_dbd.html#sessiondbdselectlabel">SessionDBDSelectLabel</a></li>
<li><a href="mod_session_dbd.html#sessiondbdupdatelabel">SessionDBDUpdateLabel</a></li>
<li><a href="mod_session.html#sessionenv">SessionEnv</a></li>
<li><a href="mod_session.html#sessionexclude">SessionExclude</a></li>
<li><a href="mod_session.html#sessionexpiryupdateinterval">SessionExpiryUpdateInterval</a></li>
<li><a href="mod_session.html#sessionheader">SessionHeader</a></li>
<li><a href="mod_session.html#sessioninclude">SessionInclude</a></li>
<li><a href="mod_session.html#sessionmaxage">SessionMaxAge</a></li>
<li><a href="mod_env.html#setenv">SetEnv</a></li>
<li><a href="mod_setenvif.html#setenvif">SetEnvIf</a></li>
<li><a href="mod_setenvif.html#setenvifexpr">SetEnvIfExpr</a></li>
<li><a href="mod_setenvif.html#setenvifnocase">SetEnvIfNoCase</a></li>
<li><a href="core.html#sethandler">SetHandler</a></li>
<li><a href="core.html#setinputfilter">SetInputFilter</a></li>
<li><a href="core.html#setoutputfilter">SetOutputFilter</a></li>
<li><a href="mod_include.html#ssiendtag">SSIEndTag</a></li>
<li><a href="mod_include.html#ssierrormsg">SSIErrorMsg</a></li>
<li><a href="mod_include.html#ssietag">SSIETag</a></li>
<li><a href="mod_include.html#ssilastmodified">SSILastModified</a></li>
<li><a href="mod_include.html#ssilegacyexprparser">SSILegacyExprParser</a></li>
<li><a href="mod_include.html#ssistarttag">SSIStartTag</a></li>
<li><a href="mod_include.html#ssitimeformat">SSITimeFormat</a></li>
<li><a href="mod_include.html#ssiundefinedecho">SSIUndefinedEcho</a></li>
<li><a href="mod_ssl.html#sslcacertificatefile">SSLCACertificateFile</a></li>
<li><a href="mod_ssl.html#sslcacertificatepath">SSLCACertificatePath</a></li>
<li><a href="mod_ssl.html#sslcadnrequestfile">SSLCADNRequestFile</a></li>
<li><a href="mod_ssl.html#sslcadnrequestpath">SSLCADNRequestPath</a></li>
<li><a href="mod_ssl.html#sslcarevocationcheck">SSLCARevocationCheck</a></li>
<li><a href="mod_ssl.html#sslcarevocationfile">SSLCARevocationFile</a></li>
<li><a href="mod_ssl.html#sslcarevocationpath">SSLCARevocationPath</a></li>
<li><a href="mod_ssl.html#sslcertificatechainfile">SSLCertificateChainFile</a></li>
<li><a href="mod_ssl.html#sslcertificatefile">SSLCertificateFile</a></li>
<li><a href="mod_ssl.html#sslcertificatekeyfile">SSLCertificateKeyFile</a></li>
<li><a href="mod_ssl.html#sslciphersuite">SSLCipherSuite</a></li>
<li><a href="mod_ssl.html#sslcompression">SSLCompression</a></li>
<li><a href="mod_ssl.html#sslcryptodevice">SSLCryptoDevice</a></li>
<li><a href="mod_ssl.html#sslengine">SSLEngine</a></li>
<li><a href="mod_ssl.html#sslfips">SSLFIPS</a></li>
<li><a href="mod_ssl.html#sslhonorcipherorder">SSLHonorCipherOrder</a></li>
<li><a href="mod_ssl.html#sslinsecurerenegotiation">SSLInsecureRenegotiation</a></li>
<li><a href="mod_ssl.html#sslocspdefaultresponder">SSLOCSPDefaultResponder</a></li>
<li><a href="mod_ssl.html#sslocspenable">SSLOCSPEnable</a></li>
<li><a href="mod_ssl.html#sslocspnoverify">SSLOCSPNoverify</a></li>
<li><a href="mod_ssl.html#sslocspoverrideresponder">SSLOCSPOverrideResponder</a></li>
<li><a href="mod_ssl.html#sslocspproxyurl">SSLOCSPProxyURL</a></li>
<li><a href="mod_ssl.html#sslocsprespondercertificatefile">SSLOCSPResponderCertificateFile</a></li>
<li><a href="mod_ssl.html#sslocsprespondertimeout">SSLOCSPResponderTimeout</a></li>
<li><a href="mod_ssl.html#sslocspresponsemaxage">SSLOCSPResponseMaxAge</a></li>
<li><a href="mod_ssl.html#sslocspresponsetimeskew">SSLOCSPResponseTimeSkew</a></li>
<li><a href="mod_ssl.html#sslocspuserequestnonce">SSLOCSPUseRequestNonce</a></li>
<li><a href="mod_ssl.html#sslopensslconfcmd">SSLOpenSSLConfCmd</a></li>
<li><a href="mod_ssl.html#ssloptions">SSLOptions</a></li>
<li><a href="mod_ssl.html#sslpassphrasedialog">SSLPassPhraseDialog</a></li>
<li><a href="mod_ssl.html#sslprotocol">SSLProtocol</a></li>
<li><a href="mod_ssl.html#sslproxycacertificatefile">SSLProxyCACertificateFile</a></li>
<li><a href="mod_ssl.html#sslproxycacertificatepath">SSLProxyCACertificatePath</a></li>
<li><a href="mod_ssl.html#sslproxycarevocationcheck">SSLProxyCARevocationCheck</a></li>
<li><a href="mod_ssl.html#sslproxycarevocationfile">SSLProxyCARevocationFile</a></li>
<li><a href="mod_ssl.html#sslproxycarevocationpath">SSLProxyCARevocationPath</a></li>
<li><a href="mod_ssl.html#sslproxycheckpeercn">SSLProxyCheckPeerCN</a></li>
<li><a href="mod_ssl.html#sslproxycheckpeerexpire">SSLProxyCheckPeerExpire</a></li>
<li><a href="mod_ssl.html#sslproxycheckpeername">SSLProxyCheckPeerName</a></li>
<li><a href="mod_ssl.html#sslproxyciphersuite">SSLProxyCipherSuite</a></li>
<li><a href="mod_ssl.html#sslproxyengine">SSLProxyEngine</a></li>
<li><a href="mod_ssl.html#sslproxymachinecertificatechainfile">SSLProxyMachineCertificateChainFile</a></li>
<li><a href="mod_ssl.html#sslproxymachinecertificatefile">SSLProxyMachineCertificateFile</a></li>
<li><a href="mod_ssl.html#sslproxymachinecertificatepath">SSLProxyMachineCertificatePath</a></li>
<li><a href="mod_ssl.html#sslproxyprotocol">SSLProxyProtocol</a></li>
<li><a href="mod_ssl.html#sslproxyverify">SSLProxyVerify</a></li>
<li><a href="mod_ssl.html#sslproxyverifydepth">SSLProxyVerifyDepth</a></li>
<li><a href="mod_ssl.html#sslrandomseed">SSLRandomSeed</a></li>
<li><a href="mod_ssl.html#sslrenegbuffersize">SSLRenegBufferSize</a></li>
<li><a href="mod_ssl.html#sslrequire">SSLRequire</a></li>
<li><a href="mod_ssl.html#sslrequiressl">SSLRequireSSL</a></li>
<li><a href="mod_ssl.html#sslsessioncache">SSLSessionCache</a></li>
<li><a href="mod_ssl.html#sslsessioncachetimeout">SSLSessionCacheTimeout</a></li>
<li><a href="mod_ssl.html#sslsessionticketkeyfile">SSLSessionTicketKeyFile</a></li>
<li><a href="mod_ssl.html#sslsessiontickets">SSLSessionTickets</a></li>
<li><a href="mod_ssl.html#sslsrpunknownuserseed">SSLSRPUnknownUserSeed</a></li>
<li><a href="mod_ssl.html#sslsrpverifierfile">SSLSRPVerifierFile</a></li>
<li><a href="mod_ssl.html#sslstaplingcache">SSLStaplingCache</a></li>
<li><a href="mod_ssl.html#sslstaplingerrorcachetimeout">SSLStaplingErrorCacheTimeout</a></li>
<li><a href="mod_ssl.html#sslstaplingfaketrylater">SSLStaplingFakeTryLater</a></li>
<li><a href="mod_ssl.html#sslstaplingforceurl">SSLStaplingForceURL</a></li>
<li><a href="mod_ssl.html#sslstaplingrespondertimeout">SSLStaplingResponderTimeout</a></li>
<li><a href="mod_ssl.html#sslstaplingresponsemaxage">SSLStaplingResponseMaxAge</a></li>
<li><a href="mod_ssl.html#sslstaplingresponsetimeskew">SSLStaplingResponseTimeSkew</a></li>
<li><a href="mod_ssl.html#sslstaplingreturnrespondererrors">SSLStaplingReturnResponderErrors</a></li>
<li><a href="mod_ssl.html#sslstaplingstandardcachetimeout">SSLStaplingStandardCacheTimeout</a></li>
<li><a href="mod_ssl.html#sslstrictsnivhostcheck">SSLStrictSNIVHostCheck</a></li>
<li><a href="mod_ssl.html#sslusername">SSLUserName</a></li>
<li><a href="mod_ssl.html#sslusestapling">SSLUseStapling</a></li>
<li><a href="mod_ssl.html#sslverifyclient">SSLVerifyClient</a></li>
<li><a href="mod_ssl.html#sslverifydepth">SSLVerifyDepth</a></li>
<li><a href="mod_ssl.html#sslvhostsnipolicy">SSLVHostSNIPolicy</a></li>
<li><a href="mpm_common.html#startservers">StartServers</a></li>
<li><a href="mpm_common.html#startthreads">StartThreads</a></li>
<li><a href="core.html#stricthostcheck">StrictHostCheck</a></li>
<li><a href="mod_substitute.html#substitute">Substitute</a></li>
<li><a href="mod_substitute.html#substituteinheritbefore">SubstituteInheritBefore</a></li>
<li><a href="mod_substitute.html#substitutemaxlinelength">SubstituteMaxLineLength</a></li>
<li><a href="mod_unixd.html#suexec">Suexec</a></li>
<li><a href="mod_suexec.html#suexecusergroup">SuexecUserGroup</a></li>
<li><a href="mpm_common.html#threadlimit" id="T" name="T">ThreadLimit</a></li>
<li><a href="mpm_common.html#threadsperchild">ThreadsPerChild</a></li>
<li><a href="mpm_common.html#threadstacksize">ThreadStackSize</a></li>
<li><a href="core.html#timeout">TimeOut</a></li>
<li><a href="core.html#traceenable">TraceEnable</a></li>
<li><a href="mod_log_config.html#transferlog">TransferLog</a></li>
<li><a href="mod_mime.html#typesconfig">TypesConfig</a></li>
<li><a href="core.html#unclist" id="U" name="U">UNCList</a></li>
<li><a href="core.html#undefine">UnDefine</a></li>
<li><a href="mod_macro.html#undefmacro">UndefMacro</a></li>
<li><a href="mod_env.html#unsetenv">UnsetEnv</a></li>
<li><a href="mod_macro.html#use">Use</a></li>
<li><a href="core.html#usecanonicalname">UseCanonicalName</a></li>
<li><a href="core.html#usecanonicalphysicalport">UseCanonicalPhysicalPort</a></li>
<li><a href="mod_unixd.html#user">User</a></li>
<li><a href="mod_userdir.html#userdir">UserDir</a></li>
<li><a href="mod_privileges.html#vhostcgimode" id="V" name="V">VHostCGIMode</a></li>
<li><a href="mod_privileges.html#vhostcgiprivs">VHostCGIPrivs</a></li>
<li><a href="mod_privileges.html#vhostgroup">VHostGroup</a></li>
<li><a href="mod_privileges.html#vhostprivs">VHostPrivs</a></li>
<li><a href="mod_privileges.html#vhostsecure">VHostSecure</a></li>
<li><a href="mod_privileges.html#vhostuser">VHostUser</a></li>
<li><a href="mod_vhost_alias.html#virtualdocumentroot">VirtualDocumentRoot</a></li>
<li><a href="mod_vhost_alias.html#virtualdocumentrootip">VirtualDocumentRootIP</a></li>
<li><a href="core.html#virtualhost">&lt;VirtualHost&gt;</a></li>
<li><a href="mod_vhost_alias.html#virtualscriptalias">VirtualScriptAlias</a></li>
<li><a href="mod_vhost_alias.html#virtualscriptaliasip">VirtualScriptAliasIP</a></li>
<li><a href="mod_watchdog.html#watchdoginterval" id="W" name="W">WatchdogInterval</a></li>
<li><a href="mod_include.html#xbithack" id="X" name="X">XBitHack</a></li>
<li><a href="mod_xml2enc.html#xml2encalias">xml2EncAlias</a></li>
<li><a href="mod_xml2enc.html#xml2encdefault">xml2EncDefault</a></li>
<li><a href="mod_xml2enc.html#xml2startparse">xml2StartParse</a></li>
</ul></div>
<div class="bottomlang">
<p><span>Idiomas disponibles: </span><a href="../de/mod/directives.html" hreflang="de" rel="alternate" title="Deutsch">&nbsp;de&nbsp;</a> |
<a href="../en/mod/directives.html" hreflang="en" rel="alternate" title="English">&nbsp;en&nbsp;</a> |
<a href="../es/mod/directives.html" title="Espa&#241;ol">&nbsp;es&nbsp;</a> |
<a href="../fr/mod/directives.html" hreflang="fr" rel="alternate" title="Fran&#231;ais">&nbsp;fr&nbsp;</a> |
<a href="../ja/mod/directives.html" hreflang="ja" rel="alternate" title="Japanese">&nbsp;ja&nbsp;</a> |
<a href="../ko/mod/directives.html" hreflang="ko" rel="alternate" title="Korean">&nbsp;ko&nbsp;</a> |
<a href="../tr/mod/directives.html" hreflang="tr" rel="alternate" title="T&#252;rk&#231;e">&nbsp;tr&nbsp;</a> |
<a href="../zh-cn/mod/directives.html" hreflang="zh-cn" rel="alternate" title="Simplified Chinese">&nbsp;zh-cn&nbsp;</a></p>
</div><div class="top"><a href="#page-header"><img src="../images/up.gif" alt="top" /></a></div><div class="section"><h2><a id="comments_section" name="comments_section">Comentarios</a></h2><div class="warning"><strong>Notice:</strong><br />This is not a Q&amp;A section. Comments placed here should be pointed towards suggestions on improving the documentation or server, and may be removed by our moderators if they are either implemented or considered invalid/off-topic. Questions on how to manage the Apache HTTP Server should be directed at either our IRC channel, #httpd, on Libera.chat, or sent to our <a href="https://httpd.apache.org/lists.html">mailing lists</a>.</div>
<script type="text/javascript"><!--//--><![CDATA[//><!--
var comments_shortname = 'httpd';
var comments_identifier = 'http://httpd.apache.org/docs/2.4/mod/directives.html';
(function(w, d) {
    if (w.location.hostname.toLowerCase() == "httpd.apache.org") {
        d.write('<div id="comments_thread"><\/div>');
        var s = d.createElement('script');
        s.type = 'text/javascript';
        s.async = true;
        s.src = 'https://comments.apache.org/show_comments.lua?site=' + comments_shortname + '&page=' + comments_identifier;
        (d.getElementsByTagName('head')[0] || d.getElementsByTagName('body')[0]).appendChild(s);
    }
    else { 
        d.write('<div id="comments_thread">Comments are disabled for this page at the moment.<\/div>');
    }
})(window, document);
//--><!]]></script></div><div id="footer">
<p class="apache">Copyright 2025 The Apache Software Foundation.<br />Licencia bajo los t&#233;rminos de la <a href="http://www.apache.org/licenses/LICENSE-2.0">Apache License, Version 2.0</a>.</p>
<p class="menu"><a href="../mod/">M&#243;dulos</a> | <a href="../mod/directives.html">Directivas</a> | <a href="http://wiki.apache.org/httpd/FAQ">Preguntas Frecuentes</a> | <a href="../glossary.html">Glosario</a> | <a href="../sitemap.html">Mapa del sitio web</a></p></div><script type="text/javascript"><!--//--><![CDATA[//><!--
if (typeof(prettyPrint) !== 'undefined') {
    prettyPrint();
}
//--><!]]></script>
</body></html>